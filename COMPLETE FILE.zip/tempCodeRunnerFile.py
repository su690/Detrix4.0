import speech_recognition as sr
import pyttsx3